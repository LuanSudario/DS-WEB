

 function aparecer(){
    document.getElementById("foto").setAttribute("src", "pato.jpg");
 }
 function mudar(){
    document.getElementById("foto").setAttribute("src", "pertubador.jpg");
 }