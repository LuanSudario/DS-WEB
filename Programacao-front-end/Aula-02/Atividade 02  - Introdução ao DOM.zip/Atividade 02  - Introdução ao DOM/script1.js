function mudaTamanho(){
    document.getElementById("conteudo").innerHTML = "<h1>Texto</h1>"
    console.log(document.getElementById("conteudo").innerHTML)
    document.getElementById("conteudo").style.backgroundColor = "lightblue";
}