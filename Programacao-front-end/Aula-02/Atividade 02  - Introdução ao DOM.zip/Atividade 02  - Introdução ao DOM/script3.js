function azul(){
    document.getElementById("fundo").innerHTML = "<h1>AZUL</h1>";
    document.getElementById("fundo").style.backgroundColor = "blue";
    document.getElementById("fundo").style.width = "1500px";
}

function vermelho(){
    document.getElementById("fundo").innerHTML = "<h1>VERMELHO</h1>";
    document.getElementById("fundo").style.backgroundColor = "red";
    document.getElementById("fundo").style.width = "1500px";
}

function verde(){
    document.getElementById("fundo").innerHTML = "<h1>VERDE</h1>";
    document.getElementById("fundo").style.backgroundColor = "green";
    document.getElementById("fundo").style.width = "1500px";
}

